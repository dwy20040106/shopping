create definer = root@localhost view view_cart_items as
select `c`.`id`                       AS `cart_id`,
       `c`.`user_id`                  AS `user_id`,
       `p`.`id`                       AS `product_id`,
       `p`.`name`                     AS `product_name`,
       `p`.`price`                    AS `price`,
       `c`.`quantity`                 AS `quantity`,
       (`p`.`price` * `c`.`quantity`) AS `subtotal`
from (`shopping_platform`.`cart_items` `c` join `shopping_platform`.`products` `p` on ((`c`.`product_id` = `p`.`id`)));

-- comment on column view_cart_items.cart_id not supported: 购物车项ID

-- comment on column view_cart_items.user_id not supported: 用户ID，外键关联users

-- comment on column view_cart_items.product_id not supported: 商品ID，主键

-- comment on column view_cart_items.product_name not supported: 商品名称

-- comment on column view_cart_items.price not supported: 商品单价，单位元

-- comment on column view_cart_items.quantity not supported: 加入购物车的商品数量

