create definer = root@localhost view view_product_info as
select `p`.`id`          AS `product_id`,
       `p`.`name`        AS `name`,
       `p`.`description` AS `description`,
       `p`.`price`       AS `price`,
       `p`.`stock`       AS `stock`,
       `s`.`name`        AS `store_name`,
       `pi`.`image_url`  AS `cover_image`
from ((`shopping_platform`.`products` `p` join `shopping_platform`.`stores` `s`
       on ((`p`.`store_id` = `s`.`id`))) left join (select `shopping_platform`.`product_images`.`product_id`     AS `product_id`,
                                                           min(`shopping_platform`.`product_images`.`image_url`) AS `image_url`
                                                    from `shopping_platform`.`product_images`
                                                    group by `shopping_platform`.`product_images`.`product_id`) `pi`
      on ((`p`.`id` = `pi`.`product_id`)));

-- comment on column view_product_info.product_id not supported: 商品ID，主键

-- comment on column view_product_info.name not supported: 商品名称

-- comment on column view_product_info.description not supported: 商品描述

-- comment on column view_product_info.price not supported: 商品单价，单位元

-- comment on column view_product_info.stock not supported: 库存数量

-- comment on column view_product_info.store_name not supported: 店铺名称

-- comment on column view_product_info.cover_image not supported: 图片链接地址

