create definer = root@localhost view view_product_sales as
select `p`.`id`             AS `product_id`,
       `p`.`name`           AS `product_name`,
       `s`.`name`           AS `store_name`,
       sum(`oi`.`quantity`) AS `total_sales`
from (((`shopping_platform`.`products` `p` join `shopping_platform`.`stores` `s`
        on ((`p`.`store_id` = `s`.`id`))) join `shopping_platform`.`order_items` `oi`
       on ((`p`.`id` = `oi`.`product_id`))) join `shopping_platform`.`orders` `o` on ((`oi`.`order_id` = `o`.`id`)))
where (`o`.`status` <> 'cancelled')
group by `p`.`id`;

-- comment on column view_product_sales.product_id not supported: 商品ID，主键

-- comment on column view_product_sales.product_name not supported: 商品名称

-- comment on column view_product_sales.store_name not supported: 店铺名称

